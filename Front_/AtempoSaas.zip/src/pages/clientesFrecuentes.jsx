import React, { useState } from 'react';
import '../styles/clientesFrecuentes.css';
import ModalNuevoClienteFrecuente from '../components/modalNuevoClienteFrecuente/modalNuevoClienteFrecuente';
import { FaUserPlus, FaEdit, FaTrash } from 'react-icons/fa';

const ClientesFrecuentes = () => {
    const [mostrarModal, setMostrarModal] = useState(false);

    const clientes = [
        { id: 1, nombre: 'Nombre(s) del cliente', apellidos: 'Apellidos del cliente', celular: '12345678' },
        { id: 2, nombre: 'Nombre(s) del cliente', apellidos: 'Apellidos del cliente', celular: '12345678' },
        { id: 3, nombre: 'Nombre(s) del cliente', apellidos: 'Apellidos del cliente', celular: '12345678' },
        { id: 4, nombre: 'Nombre(s) del cliente', apellidos: 'Apellidos del cliente', celular: '12345678' },
        { id: 5, nombre: 'Nombre(s) del cliente', apellidos: 'Apellidos del cliente', celular: '12345678' },
        { id: 6, nombre: 'Nombre(s) del cliente', apellidos: 'Apellidos del cliente', celular: '12345678' },
    ];

    return (
        <div className="clientes-container">
            <div className="header-clientes">
                <h2 className="titulo-clientes">Clientes frecuentes</h2>
                <button className="nuevo-cliente-btn" onClick={() => setMostrarModal(true)}>
                    Nuevo cliente frecuente <FaUserPlus className="icono-btn" />
                </button>
            </div>
            <table className="tabla-clientes">
                <thead>
                    <tr>
                        <th>Nombre(s)</th>
                        <th>Apellidos</th>
                        <th>Número celular</th>
                        <th>Opciones</th>
                    </tr>
                </thead>
                <tbody>
                    {clientes.map((cliente) => (
                        <tr key={cliente.id}>
                            <td>{cliente.nombre}</td>
                            <td>{cliente.apellidos}</td>
                            <td>{cliente.celular}</td>
                            <td>
                                <FaEdit className="icono-editar" />
                                <FaTrash className="icono-borrar" />
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
            {mostrarModal && (
                <ModalNuevoClienteFrecuente onClose={() => setMostrarModal(false)} />
            )}
        </div>
    );
};

export default ClientesFrecuentes;
