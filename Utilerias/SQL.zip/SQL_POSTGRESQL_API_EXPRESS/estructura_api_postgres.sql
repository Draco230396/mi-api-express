-- ============================================
-- ESTRUCTURA DE TABLAS PARA API DE CITAS
-- Base de Datos: PostgreSQL
-- Autor: Romeo Cuahua Galvez
-- ============================================

-- ============================================
-- CREACI�N DE TABLA PERSONAS
-- ============================================
CREATE TABLE personas (
  id_persona     SERIAL PRIMARY KEY,
  nombre         VARCHAR(100) NOT NULL,
  email          VARCHAR(100),
  telefono       VARCHAR(20)
);

-- ============================================
-- CREACI�N DE TABLA CITAS
-- ============================================
CREATE TABLE citas (
  id_cita        SERIAL PRIMARY KEY,
  id_persona     INTEGER NOT NULL,
  fecha_hora     TIMESTAMP NOT NULL,
  motivo         VARCHAR(200),
  CONSTRAINT fk_citas_persona FOREIGN KEY (id_persona)
    REFERENCES personas(id_persona)
);

-- ============================================
-- CREACI�N DE TABLA AVISOS
-- ============================================
CREATE TABLE avisos (
  id_aviso       SERIAL PRIMARY KEY,
  id_persona     INTEGER NOT NULL,
  id_cita        INTEGER NOT NULL,
  mensaje        VARCHAR(300) NOT NULL,
  fecha_aviso    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_avisos_persona FOREIGN KEY (id_persona)
    REFERENCES personas(id_persona),
  CONSTRAINT fk_avisos_cita FOREIGN KEY (id_cita)
    REFERENCES citas(id_cita)
);

-- ============================================
-- NUEVA TABLA USUARIOS (para registro y login)
-- ============================================
CREATE TABLE usuarios (
  id_usuario     SERIAL PRIMARY KEY,
  nombre         VARCHAR(100) NOT NULL,
  correo         VARCHAR(100) UNIQUE NOT NULL,
  telefono       VARCHAR(20),
  password       VARCHAR(255) NOT NULL -- Aqu� se guarda el hash
);

-- ============================================
-- DATOS DE PRUEBA
-- ============================================

-- Insertar personas
INSERT INTO personas (nombre, email, telefono) VALUES 
('Juan P�rez', 'juan@mail.com', '5551234567'),
('Ana L�pez', 'ana@mail.com', '5556781234');

-- Insertar citas
-- Cita para ma�ana
INSERT INTO citas (id_persona, fecha_hora, motivo) VALUES 
(1, NOW() + INTERVAL '1 day', 'Consulta general');

-- Cita para dentro de 3 horas
INSERT INTO citas (id_persona, fecha_hora, motivo) VALUES 
(2, NOW() + INTERVAL '3 hours', 'Chequeo m�dico');

-- ============================================
-- COMMIT FINAL (opcional si usas transacciones)
-- ============================================
COMMIT;
