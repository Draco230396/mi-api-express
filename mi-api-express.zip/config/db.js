require('dotenv').config();
const oracledb = require('oracledb');
const { Pool } = require('pg');

const DB_CLIENT = process.env.DB_CLIENT;

let pool;

async function connect() {
  if (DB_CLIENT === 'oracle') {
    pool = await oracledb.getConnection({
      user: 'C##DRACO',
      password: 'N4tur4l3s*_#',
      connectString: 'localhost:1521/xe'
    });
  } else if (DB_CLIENT === 'postgres') {
    pool = new Pool({
      user: 'postgres',
      host: 'localhost',
      database: 'mi_bd',
      password: 'mi_clave',
      port: 5432
    });
  } else {
    throw new Error('Base de datos no soportada');
  }
}

async function query(sql, params = []) {
  if (DB_CLIENT === 'oracle') {
    return pool.execute(sql, params, { outFormat: oracledb.OUT_FORMAT_OBJECT });
  } else if (DB_CLIENT === 'postgres') {
    return pool.query(sql, params);
  }
}

module.exports = { connect, query };