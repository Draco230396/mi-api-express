module.exports = {
  INSERT: `INSERT INTO avisos (id_aviso, id_persona, id_cita, mensaje, fecha_aviso) VALUES ($1, $2, $3, $4, $5)`,
  SELECT_BY_PERSONA_CITA_MENSAJE_POSTGRES: `SELECT * FROM avisos WHERE id_persona = $1 AND id_cita = $2 AND mensaje = $3`
};
