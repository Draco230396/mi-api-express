// ejemplo para evitar SQL inyección y facilitar la verificación, crea una consulta aparte
module.exports = {
  INSERT: `INSERT INTO AVISOS (ID_AVISO, ID_PERSONA, ID_CITA, MENSAJE, FECHA_AVISO) VALUES (:1, :2, :3, :4, :5)`,
  SELECT_BY_PERSONA_CITA_MENSAJE_ORACLE: `SELECT * FROM AVISOS WHERE ID_PERSONA = :1 AND ID_CITA = :2 AND MENSAJE = :3`
};
