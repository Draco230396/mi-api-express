const express = require('express');
const app = express();
const db = require('./config/db');
require('dotenv').config();

// Importa el notificador
const { generarAvisos } = require('./utils/notificador');

app.use(express.json());

app.use('/api/citas', require('./routes/cita.routes'));
app.use('/api/avisos', require('./routes/aviso.routes'));
app.use('/api/personas', require('./routes/persona.routes'));

db.connect().then(() => {
  app.listen(3000, () => {
    console.log('Servidor iniciado en http://localhost:3000');
  });

  // Ejecuta la función generarAvisos cada 30 minutos (1800000 ms)
  const INTERVALO_MINUTOS = 30;
  setInterval(() => {
    generarAvisos();
  }, INTERVALO_MINUTOS * 60 * 1000);

}).catch(err => {
  console.error('Error al conectar a la base de datos:', err);
});
